/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROGRAM_2_KONDISI;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class DUA_KONDISI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int sudut;
        System.out.println("input nilai sudut (1-360) :");
        sudut = input.nextInt();

        if (sudut >= 1 && sudut < 90) {
            System.out.println("sudut lancip");
        } else if (sudut >= 90 && sudut < 180) {
            System.out.println("sudut tumpul");
        } else {
            System.out.println("sudut refleks");
        }
    }
}
