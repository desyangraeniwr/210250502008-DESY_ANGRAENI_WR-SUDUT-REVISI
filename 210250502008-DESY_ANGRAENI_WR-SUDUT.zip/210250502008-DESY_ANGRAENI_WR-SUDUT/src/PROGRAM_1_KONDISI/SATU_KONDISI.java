/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROGRAM_1_KONDISI;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class SATU_KONDISI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int sudut;
        System.out.println("imput nilai sudut (1-180) :");
        sudut = input.nextInt();
        
        if (sudut < 90) {
            System.out.println("sudut lancip");
        } else {
            System.out.println("sudut tumpul");
        }
    }
}
